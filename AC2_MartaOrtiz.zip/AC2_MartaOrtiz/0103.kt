// Marta Ortiz González

fun main() {

    val x: Long = 3

    val dia = when (x) {
        1L -> "LUNES"
        2L -> "MARTES"
        3L -> "MIÉRCOLES"
        4L -> "JUEVES"
        5L -> "VIERNES"
        6L, 7L -> "FIN DE SEMANA"
        else -> "ERROR: El número NO es válido"
    }

    println(dia)
}