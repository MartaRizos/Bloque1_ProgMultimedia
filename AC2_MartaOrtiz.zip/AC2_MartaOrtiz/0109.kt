// Marta Ortiz González

data class Coche(
    val marca: String? = "Desconocida",
    val modelo: String? = "Desconocido",
    val lanzamiento: Int? = 0,
)

fun main() {

    val coche1 = Coche("Renault", "Captur", 2024)
    val coche2 = Coche("Honda", "Civic", 2023)
    val coche3 = Coche("Citröen", "Xsara Picasso")

    println(coche1)
    println(coche2)
    println(coche3)
}