// Marta Ortiz González

fun main() {

    // Suponemos que solamente queremos números enteros
    var x: Int?

    // Bucle do-while por si el usuario no introduce un número entero
    do {
        print("Introduce un número entero: ")
        // Comprobamos si x es entero y si no lo transformamos en null
        x = readln().toIntOrNull()

        if (x == null) {
            println("ERROR: Entrada no válida. Debe ser un número entero.")
        }

    } while (x == null)

    for (i in 0..10) {
        println("$x x $i = ${x * i}")
    }
}

