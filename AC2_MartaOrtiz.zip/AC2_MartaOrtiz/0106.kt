// Marta Ortiz González

fun comprobarEntero(): Int {
    var x: Int?

    do {
        print("Introduce un número entero: ")
        x = readln().toIntOrNull()

        if (x == null) {
            println("ERROR: Entrada no válida. Debe ser un número entero.")
        }

    } while (x == null)

    return x!!
}

fun esPrimo(x: Int) {

    if (x < 2) {
        println("No es primo")
        return
    }

    for (i in 2 until x) {
        if (x % i == 0) {
            println("No es primo")
            return
        }
    }

    println("Es primo")
}

fun main() {

    val x = comprobarEntero()

    esPrimo(x)
}