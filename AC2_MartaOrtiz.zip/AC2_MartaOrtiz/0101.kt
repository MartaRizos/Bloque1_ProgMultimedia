// Marta Ortiz González

fun main() {

    val x: Long = 100
    val y: Long = 57

    println("La suma de ${x} y ${y} es: ${x + y}")
    println("La resta de ${x} y ${y} es: ${x - y}")
    println("La multiplicación de ${x} y ${y} es: ${x * y}")
    println("La división de ${x} y ${y} es: ${x / y}")
    println("El resto de ${x} y ${y} es: ${x % y}")
}