// Marta Ortiz González

fun main() {

    val diasSemana = arrayOf(
        "LUNES",
        "MARTES",
        "MIÉRCOLES",
        "JUEVES",
        "VIERNES",
        "SÁBADO",
        "DOMINGO"
    )

    print("Introduce un número del 1 al 7: ")
    val x = readln().toIntOrNull()

    if (x != null && x in 1..7) {
        println(diasSemana[x - 1])
    } else {
        println("Valor introducido no válido. Los valores aceptables son:")

        for (i in diasSemana.indices) {
            println("${i + 1} = ${diasSemana[i]}")
        }
    }
}