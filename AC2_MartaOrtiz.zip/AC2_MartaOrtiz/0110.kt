// Marta Ortiz González

class Libro {

    var autor: String? = "Anónimo"
        set(value) {
            field = value?: "Anónimo"
        }

    var titulo: String? = "No indicado"
        set(value) {
            field = value?: "No indicado"
        }

    var anyo: Int? = -1
        set(value) {
            field = value?: -1
        }

    fun mostrarDatos(): String {
        return "Título: $titulo - Autor: $autor - Año: $anyo"
    }
}

fun main() {

    val libro1 = Libro()

    libro1.autor = "La verdad sobre el caso Savolta"
    libro1.titulo = "Eduardo Mendoza"
    libro1.anyo = 1975

    val libro2 = Libro()

    libro2.titulo = "Cien años de soledad"
    libro2.autor = "Gabriel García Márquez"

    println(libro1.mostrarDatos())
    println(libro2.mostrarDatos())
}