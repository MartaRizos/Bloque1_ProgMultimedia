// Marta Ortiz González

fun main() {

    val textos = mutableListOf<String>()

    var textoIntroducido: String?

    do {
        print("Introduce cualquier texto: ")
        textoIntroducido = readlnOrNull()

        if (textoIntroducido != null && textoIntroducido.uppercase() != "FIN") {
            textos.add(textoIntroducido)
        }

    } while (textoIntroducido == null || textoIntroducido.uppercase() != "FIN")

    println("Lista invertida:")

    for (i in textos.size - 1 downTo 0) {
        println(textos[i])
    }

    println("Lista ascendente:")

    for (texto in textos) {
        println(texto)
    }
}