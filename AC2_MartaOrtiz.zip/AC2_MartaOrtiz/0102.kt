// Marta Ortiz González

fun main() {

    val x: Long = 37

    val resultado = if (x % 2L == 0L) {
        "El número ${x} es par"
    } else {
        "El número ${x} es impar"
    }

    println(resultado)
}
