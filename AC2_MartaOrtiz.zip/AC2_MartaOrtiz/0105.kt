// Marta Ortiz González

fun main() {

    print("Introduce una palabra o frase: ")
    val textoIntroducido = readln()

    // Suponemos que no es importante eliminar el espacio sobrante al final con .trim()
    for (caracter in textoIntroducido) {
        print("$caracter ")
    }
}